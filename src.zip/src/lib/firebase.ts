import { getApp, getApps, initializeApp, type FirebaseApp } from "firebase/app";
import {
  GoogleAuthProvider,
  browserLocalPersistence,
  getAuth,
  linkWithPopup,
  onAuthStateChanged,
  setPersistence,
  signInAnonymously,
  signInWithCredential,
  signInWithPopup,
  signOut,
  type Auth,
  type Unsubscribe,
  type User,
} from "firebase/auth";
import { getFirestore, type Firestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

export const isFirebaseConfigured = Boolean(
  firebaseConfig.apiKey &&
    firebaseConfig.authDomain &&
    firebaseConfig.projectId &&
    firebaseConfig.appId,
);

let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;

if (isFirebaseConfigured) {
  app = getApps().length ? getApp() : initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
}

export { app, auth, db };

export async function ensureFirebaseUser(): Promise<User | null> {
  if (!auth) return null;

  await setPersistence(auth, browserLocalPersistence);

  if (auth.currentUser) return auth.currentUser;

  const credential = await signInAnonymously(auth);
  return credential.user;
}

export function observeFirebaseUser(callback: (user: User | null) => void): Unsubscribe {
  if (!auth) {
    callback(null);
    return () => undefined;
  }

  void setPersistence(auth, browserLocalPersistence)
    .then(() => ensureFirebaseUser())
    .catch((error) => {
      console.error("No se pudo iniciar la sesión de Firebase:", error);
    });

  return onAuthStateChanged(auth, callback);
}

export async function connectGoogleAccount(): Promise<User | null> {
  if (!auth) return null;

  await setPersistence(auth, browserLocalPersistence);
  const provider = new GoogleAuthProvider();
  provider.setCustomParameters({ prompt: "select_account" });

  const currentUser = auth.currentUser ?? (await ensureFirebaseUser());

  if (currentUser?.isAnonymous) {
    try {
      const result = await linkWithPopup(currentUser, provider);
      return result.user;
    } catch (error) {
      const code = getFirebaseErrorCode(error);

      // Si esa cuenta de Google ya existe, iniciamos sesión en ella.
      // AppContext reconectará Firestore al nuevo UID y usará los datos
      // existentes de esa cuenta (o sembrará los actuales si está vacía).
      if (
        code === "auth/credential-already-in-use" ||
        code === "auth/email-already-in-use" ||
        code === "auth/account-exists-with-different-credential"
      ) {
        const credential = GoogleAuthProvider.credentialFromError(error as Parameters<typeof GoogleAuthProvider.credentialFromError>[0]);
        if (credential) {
          const result = await signInWithCredential(auth, credential);
          return result.user;
        }
      }

      throw error;
    }
  }

  const result = await signInWithPopup(auth, provider);
  return result.user;
}

export async function disconnectGoogleAccount(): Promise<User | null> {
  if (!auth) return null;

  await signOut(auth);
  const credential = await signInAnonymously(auth);
  return credential.user;
}

function getFirebaseErrorCode(error: unknown) {
  if (
    typeof error === "object" &&
    error !== null &&
    "code" in error &&
    typeof (error as { code?: unknown }).code === "string"
  ) {
    return (error as { code: string }).code;
  }

  return "";
}
