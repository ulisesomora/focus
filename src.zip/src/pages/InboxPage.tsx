import {
  MoreHorizontal,
  Plus,
} from "lucide-react";

import { MobileLayout } from "../components/layout/MobileLayout";
import { useApp } from "../context/AppContext";
import { useNavigate } from "react-router-dom";

export function InboxPage() {
  const navigate = useNavigate();
  const {
    captures,
    snoozedCount,
    removeCapture,
  } = useApp();

  return (
    <MobileLayout>
      <header className="mb-6 lg:max-w-3xl">
        <h1 className="text-2xl font-bold text-gray-900">
          Inbox
        </h1>

        <p className="mt-1 text-sm text-gray-500">
          {captures.length === 0
            ? "Todo está organizado."
            : `${captures.length} ${
                captures.length === 1
                  ? "cosa sin organizar"
                  : "cosas sin organizar"
              }`}
        </p>
      </header>

      {snoozedCount > 0 && (
        <div className="mb-4 rounded-2xl border border-amber-100 bg-amber-50 px-4 py-3 lg:max-w-3xl">
          <p className="text-sm font-semibold text-amber-800">
            {snoozedCount} {snoozedCount === 1 ? "captura pospuesta" : "capturas pospuestas"}
          </p>
          <p className="mt-1 text-xs leading-5 text-amber-700">
            Volverán automáticamente al Inbox cuando llegue su recordatorio.
          </p>
        </div>
      )}

      {captures.length > 0 ? (
        <>
          <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white lg:max-w-3xl">
            {captures.map(
              (capture, index) => (
                <div
                  key={capture.id}
                  className={`flex items-start gap-3 px-4 py-4 ${
                    index !==
                    captures.length - 1
                      ? "border-b border-gray-100"
                      : ""
                  }`}
                >
                  <div className="mt-1 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-gray-300" />

                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-gray-900">
                      {capture.title}
                    </p>

                    <p className="mt-1 text-xs text-gray-400">
                      {formatTime(
                        capture.createdAt,
                      )}
                    </p>
                  </div>

                  <button
                    type="button"
                    className="flex h-8 w-8 items-center justify-center rounded-full text-gray-400"
                  >
                    <MoreHorizontal
                      size={19}
                    />
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      removeCapture(
                        capture.id,
                      )
                    }
                    className="text-xs font-medium text-red-500"
                  >
                    Eliminar
                  </button>
                </div>
              ),
            )}
          </div>

          <button
            type="button"
            onClick={() => navigate("/inbox/process")}
            className="mt-6 h-12 w-full rounded-2xl bg-gray-900 px-5 font-semibold text-white lg:w-auto lg:min-w-44"
          >
            Procesar Inbox
          </button>
        </>
      ) : (
        <InboxEmpty />
      )}
    </MobileLayout>
  );
}

function InboxEmpty() {
  return (
    <div className="flex min-h-[55vh] flex-col items-center justify-center text-center">
      <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-green-50 text-green-600">
        ✓
      </div>

      <h2 className="mt-5 text-xl font-bold text-gray-900">
        Inbox en orden
      </h2>

      <p className="mt-2 max-w-xs text-sm leading-6 text-gray-500">
        No tienes nada pendiente por
        organizar.
      </p>

      <button
        type="button"
        className="mt-6 flex items-center gap-2 rounded-xl border border-gray-200 bg-white px-4 py-3 text-sm font-semibold text-gray-700"
      >
        <Plus size={17} />
        Capturar algo
      </button>
    </div>
  );
}

function formatTime(date: Date) {
  return new Intl.DateTimeFormat(
    "es-MX",
    {
      hour: "numeric",
      minute: "2-digit",
    },
  ).format(date);
}