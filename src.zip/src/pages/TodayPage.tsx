import { LabelFilter, matchesLabel } from "../components/labels/LabelPicker";
import { useEffect, useMemo, useState } from "react";
import { Check, ChevronRight, MoreHorizontal } from "lucide-react";
import { Link } from "react-router-dom";
import { MobileLayout } from "../components/layout/MobileLayout";
import { SimpleTaskSheet } from "../components/tasks/SimpleTaskSheet";
import { DesktopTodayWorkspace } from "../components/today/DesktopTodayWorkspace";
import type { TaskEditorValue } from "../components/tasks/TaskEditorSheet";
import { useApp } from "../context/AppContext";
import { defaultAreas } from "../types/settings";
import type { Task } from "../types/task";

const colors = [
  { card: "bg-indigo-50 text-indigo-700", label: "bg-indigo-50 text-indigo-700" },
  { card: "bg-emerald-50 text-emerald-700", label: "bg-emerald-50 text-emerald-700" },
  { card: "bg-pink-50 text-pink-700", label: "bg-pink-50 text-pink-700" },
  { card: "bg-gray-100 text-gray-700", label: "bg-gray-100 text-gray-600" },
];

export function TodayPage() {
  const { tasks, settings, createTask, moveTask, updateTask } = useApp();
  const areas = settings.areas?.length ? settings.areas : defaultAreas;
  const focusIds = settings.focusAreaIds ?? defaultAreas.map((area) => area.id);
  const focusAreas = areas.filter((area) => focusIds.includes(area.id)).slice(0, 4);
  const [labelFilter, setLabelFilter] = useState("");
  const [selectedArea, setSelectedArea] = useState<string | null>(null);
  const [editorOpen, setEditorOpen] = useState(false);
  const [menuId, setMenuId] = useState<string | null>(null);

  useEffect(() => {
    const openTask = () => setEditorOpen(true);
    window.addEventListener("focus-open-task", openTask);
    return () => window.removeEventListener("focus-open-task", openTask);
  }, []);

  const assigned = useMemo(() => tasks.filter((task) => task.status !== "backlog" && task.status !== "cancelled"), [tasks]);
  const visible = useMemo(() => assigned.filter(task => matchesLabel(task.labels, labelFilter))
    .sort((a, b) => Number(a.status === "completed") - Number(b.status === "completed")
      || (a.plannedDate ?? "9999").localeCompare(b.plannedDate ?? "9999")
      || (a.plannedTime ?? "").localeCompare(b.plannedTime ?? "")), [assigned, labelFilter]);

  const day = new Intl.DateTimeFormat("es-MX", { weekday: "long", day: "numeric", month: "short" }).format(new Date());
  const headerDate = day.charAt(0).toUpperCase() + day.slice(1).replace(".", "");

  function toggleSubtask(task: Task, subtaskId: string) {
    updateTask(task.id, { subtasks: task.subtasks?.map((item) => item.id === subtaskId ? { ...item, completed: !item.completed } : item) });
  }

  function create(value: TaskEditorValue) {
    createTask({ ...value, status: "pending" });
  }

  function areaFor(task: Task) {
    return areas.find((area) => area.id === task.area);
  }

  return (
    <MobileLayout wideDesktop>
      <DesktopTodayWorkspace onAreaChange={setSelectedArea} />
      <div className="mx-auto max-w-2xl lg:hidden">
        <header className="mb-4 flex items-baseline gap-2">
          <h1 className="text-xl font-bold text-gray-950">Hoy</h1>
          <span className="text-sm font-medium text-gray-500">{headerDate}</span>
        </header>

        <div className="rounded-2xl border border-gray-200 bg-white p-2" aria-label="Áreas principales">
          <div className="grid grid-cols-2 gap-2">
          {focusAreas.map((area, index) => {
            const count = assigned.filter((task) => task.area === area.id).length;
            return (
              <Link key={area.id} to={`/areas/${area.id}`} className={`flex min-h-12 items-center justify-between gap-2 rounded-xl px-3 py-2 text-left ${colors[index % colors.length].card}`}>
                <span className="truncate text-xs font-semibold">{area.name}</span>
                <span className="shrink-0 text-xs font-bold">{count}</span>
              </Link>
            );
          })}
          </div>
        </div>
        <div className="mt-2 flex justify-end">
          <Link to="/areas" className="text-xs font-medium text-gray-500">Más áreas <ChevronRight size={13} className="inline" /></Link>
        </div>

        <div className="mt-4"><LabelFilter value={labelFilter} onChange={setLabelFilter} /></div>
        <section className="mt-4" aria-label="Lista de tareas">
          {visible.length ? visible.map((task) => {
            const completed = task.status === "completed";
            const area = areaFor(task);
            const areaIndex = Math.max(0, areas.findIndex((item) => item.id === area?.id));
            return (
              <div key={task.id} className="border-b border-gray-200 py-3">
                <div className="flex items-start gap-2.5">
                  <button type="button" onClick={() => moveTask(task.id, completed ? "pending" : "completed")}
                    aria-label={`${completed ? "Marcar pendiente" : "Marcar realizada"}: ${task.title}`}
                    className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded border ${completed ? "border-gray-400 bg-gray-400 text-white" : "border-gray-300 text-transparent hover:border-gray-500"}`}>
                    <Check size={14} strokeWidth={3} />
                  </button>
                  <div className="min-w-0 flex-1">
                    <p className={`text-sm leading-5 ${completed ? "text-gray-400 line-through" : "text-gray-900"}`}>{task.title}</p>
                    <div className="mt-1 flex flex-wrap items-center gap-1">
                      {area && <span className={`rounded px-1 py-0.5 text-[10px] font-semibold uppercase ${colors[areaIndex % colors.length].label}`}>{area.name}</span>}
                      {task.labels?.map((label) => <span key={label} className="rounded bg-gray-100 px-1 py-0.5 text-[10px] text-gray-600">{label}</span>)}
                      {task.plannedTime && <span className="text-[10px] text-gray-500">{task.plannedTime}</span>}
                    </div>
                  </div>
                  <div className="relative flex shrink-0 items-center">
                    <button type="button" onClick={() => setMenuId((current) => current === task.id ? null : task.id)} aria-label={`Asignar área a ${task.title}`} aria-expanded={menuId === task.id} className="flex h-8 w-8 items-center justify-center rounded-lg text-gray-500 hover:bg-gray-100"><MoreHorizontal size={19} /></button>
                    <Link to={`/tasks/${task.id}`} aria-label={`Ver tarea completa: ${task.title}`} className="flex h-8 w-8 items-center justify-center rounded-lg text-gray-500 hover:bg-gray-100"><ChevronRight size={19} /></Link>
                    {menuId === task.id && (
                      <div className="absolute right-0 top-9 z-20 w-44 rounded-xl border border-gray-200 bg-white p-1.5 shadow-lg">
                        <p className="px-2 py-1 text-[11px] font-semibold text-gray-400">Asignar área</p>
                        <button type="button" onClick={() => { updateTask(task.id, { area: undefined }); setMenuId(null); }} className="block w-full rounded-lg px-2 py-2 text-left text-xs text-gray-700 hover:bg-gray-100">Sin área{!area ? " ✓" : ""}</button>
                        {areas.map((option) => <button key={option.id} type="button" onClick={() => { updateTask(task.id, { area: option.id }); setMenuId(null); }} className="block w-full rounded-lg px-2 py-2 text-left text-xs text-gray-700 hover:bg-gray-100">{option.name}{area?.id === option.id ? " ✓" : ""}</button>)}
                        <Link to="/areas" className="block border-t border-gray-100 px-2 py-2 text-xs font-medium text-gray-600">Administrar áreas</Link>
                      </div>
                    )}
                  </div>
                </div>
                {!!task.subtasks?.length && (
                  <div className="ml-8 mt-2 space-y-1.5">
                    {task.subtasks.map((subtask) => <button key={subtask.id} type="button" onClick={() => toggleSubtask(task, subtask.id)} className="flex w-full items-start gap-2 text-left">
                      <span className={`mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded border ${subtask.completed ? "border-gray-400 bg-gray-400 text-white" : "border-gray-300 text-transparent"}`}><Check size={11} strokeWidth={3} /></span>
                      <span className={`text-xs leading-5 ${subtask.completed ? "text-gray-400 line-through" : "text-gray-700"}`}>{subtask.title}</span>
                    </button>)}
                  </div>
                )}
              </div>
            );
          }) : <p className="py-10 text-center text-sm text-gray-500">Aún no hay tareas. Usa el botón + para crear una.</p>}
        </section>
      </div>
      <SimpleTaskSheet initialArea={selectedArea ?? undefined} open={editorOpen} onClose={() => setEditorOpen(false)} onSave={create} />
    </MobileLayout>
  );
}
