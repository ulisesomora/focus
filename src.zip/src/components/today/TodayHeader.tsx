export function TodayHeader() {
  const formattedDate = new Intl.DateTimeFormat("es-MX", {
    weekday: "long",
    day: "numeric",
    month: "long",
  }).format(new Date());

  return (
    <header className="mb-6">
      <p className="text-sm font-medium capitalize text-gray-500">
        {formattedDate}
      </p>

      <div className="mt-1 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900">
            Hola 👋
          </h1>

          <p className="mt-1 text-sm text-gray-500">
            Veamos qué tienes para hoy.
          </p>
        </div>

        <button
          type="button"
          className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-200 text-sm font-semibold text-gray-700"
        >
          U
        </button>
      </div>
    </header>
  );
}
